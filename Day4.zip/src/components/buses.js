import React, { Component } from "react";
import "./buses.css";
class Buses extends Component{
    render(){
        return(
            <div class="card">
                <div class="container">
                    <p>VMT Travels</p>
                    <h4><b>John Doe</b></h4>
                </div>
            </div>
        );
    }
}

export default Buses;